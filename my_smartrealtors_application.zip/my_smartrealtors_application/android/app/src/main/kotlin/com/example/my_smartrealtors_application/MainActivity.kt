package com.example.my_smartrealtors_application

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
